tear_circ_199 full trajectory and field videos

COMPLETED: all six MP4 files fully decoded; 495 frames each.

A continuous trajectory from t=0 to 120.0959606268 ms.
Time step: 46.875 native units = 30.388654 microseconds.
Geometry: circular toroidal tokamak, major radius 10 m, minor radius 1 m.
Model199, six stored fields, toroidal n=0 and n=1, fixed pilot mesh.

The validated fresh-start run supplies 0-52.511594 ms. It is continued from
its exact restart; a native STOP_NOW checkpoint at 76.397076 ms splits the
extension across CPU allocations. This is one physical trajectory.
The original pilot data and installation are unchanged.

Earlier snapshots:
/pitagora/home/userexternal/vgopakum/NOs_for_POs_MHD/JOREK/tearing_pilot/growth_2775360/dt46.875
Later snapshots: continuation/jorekNNNNNN.h5
Completion and solver checks: run_report.json
Checkpoint diagnostic continuity: restart_continuity.json

Videos: videos/psi.mp4, u.mp4, j.mp4, omega.mp4, rho.mp4, T.mp4
Each video uses a fixed phi=0 poloidal cross-section and three panels:
  full field q0+qcos;
  change in the full field from t=0;
  n=1 perturbation qcos at phi=0.
Native bicubic fields are evaluated directly at a 241x241 R-Z image grid.
Colour scales stay fixed throughout each video. Values use native JOREK units.
495 frames, 24 fps, 20.625 seconds per video; physical frame spacing 0.243109 ms.
Video validation, colour limits and hashes: videos/render_report.json
Final-frame PNGs accompany each MP4. preview/ contains development checks only.

The simulation and rendering use separate Slurm jobs. Rendering requires
successful endpoint validation. Every final video is fully decoded and its
frame count checked. The encoder dependency is isolated in render_tools/.

Scope: a visualization run, not an OpsSplit/AR/NODE training dataset.
Timestep convergence was established for 15-50 ms in the earlier pilot;
it was not independently rechecked over 50-120 ms. Mesh and higher-toroidal-mode
convergence remain untested. These movies are 2D cuts of a toroidal simulation,
not a 3D rendering of the entire torus.

Job accounting note: job 2775459 reports FAILED because its endpoint-checking
wrapper rejected the intentionally early STOP_NOW checkpoint. JOREK itself
returned 0 with no solver/HDF5 errors and wrote a complete restart. Job 2775473
then reached the 120 ms endpoint successfully. Rendering job 2775474 completed.
The obsolete rendering dependency job 2775468 was cancelled before running.

field_videos.zip contains videos and reports only. Raw simulation checkpoints
remain in the earlier/later snapshot locations listed above.
